// Exercicio 1
let msg = "Seja bem vindo a nossa página";
alert(msg);

// Exercicio 2
function mensagem() {
    let n = "Isso é um alert";
    alert(n);
}

// Exercicio 3
function par() {
    let test = document.getElementById("test"); // Utilizei 'ById'
    test.innerHTML = "<input type='text' placeholder='Digite um número'><button class='bt'>OK</button><span class ='mostra'></span>";
    let bt = document.getElementsByClassName("bt"); // Utilizei 'ClassName' 
    let pi = document.getElementsByTagName("input"); // Utilizei 'TagName'
    let tagSpan = document.querySelector(".mostra "); //Utilizei o 'querySelector'
 
    bt[0].onclick = function () {
        if ((pi[0].value % 2) == 0) {
            tagSpan.innerHTML = " Par "; 
            tagSpan.style.color = "green";
        }
        else {
            tagSpan.innerHTML = " Ímpar ";
            tagSpan.style.color = "blue";
        }
    }
}
// 6)  Desenvolva um script qua ao clicar no botão conta o numero de vezes clicado,
// em que seja separado o HTML e o JavaScript.
let x = 0;
function cont() {
    test.innerHTML = "<button class='bt'>Clique aqui</button>";
    let bt = document.getElementsByClassName("bt");
    let conteudo = document.createElement("p");
    conteudo.textContent = "Número de cliques = "; // onde vai aparecer o numero de cliques
    test.appendChild(conteudo);
    

    bt[0].onclick = function () {
        x++;
        conteudo.innerHTML = "Número de cliques = " + x;
    }

}


// . document.querySelectorAll();


//  7) Crie uma função que receba uma string como parâmetro
//      e retorne a mesma string com todas as letras em caixa alta.
//     Utilize essa função para converter diferentes strings.
function caixa(){
    test.innerHTML = "<input type='text' id='letra' name='letra' placeholder='digite uma frase'><button class='bt'>Maiusculo</button><p></p>";
    let bt = document.getElementsByClassName("bt")[0];
    bt.onclick = function () {
        let letra = document.getElementById('letra').value;
        let resultado = document.getElementsByTagName("p");
        resultado[0].innerHTML = letra.toUpperCase();
    }
}

//  8) Crie uma função que receba dois números como parâmetros e retorne a soma deles.
//      Utilize essa função para realizar somas diferentes.

function soma (){
    test.innerHTML = "<input type='text' class= 'v1' placeholder='Valor 1'><input type='text' class='v2' placeholder=Valor 2'><button class='bt'>Calcular</button><span class ='resultado'></span>";
    
    let bt = document.getElementsByClassName("bt")[0];
    let resul = document.querySelector('.resultado');
    let v1 = document.getElementsByClassName("v1")[0];
    let v2 = document.getElementsByClassName("v2")[0];

    bt.onclick = function () {
        let soma = parseInt(v1.value) + parseInt(v2.value);
        resul.innerHTML = "Resultado: " + soma;
    }
}